package com.movie.controllers;

public class TheatreController {

}
